import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Nav from './Componente/Nav'
import Home from './Paginas/Index'
import Apod from './Paginas/Apod'
import NeoWs from './Paginas/NeoWs'
import Busca from './Paginas/Busca'


function App() {
  return (
    <BrowserRouter>
      <Nav />

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/apod" element={<Apod />} />
        <Route path="/neows" element={<NeoWs/>}/>
        <Route path="/busca" element={<Busca/>}/>
      </Routes>
    </BrowserRouter>
  )
}

export default App