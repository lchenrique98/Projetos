import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import './Busca.css'

function Busca() {
  const [data, setData] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [busca, setBusca] = useState('mars')
  const [selecionado, setSelecionado] = useState(null)

  useEffect(() => {
    const delay = setTimeout(() => {
      setLoading(true)
      setError(null)

      fetch(`https://images-api.nasa.gov/search?q=${busca}&media_type=image`)
        .then(res => {
          if (!res.ok) throw new Error(`Erro HTTP: ${res.status}`)
          return res.json()
        })
        .then(dados => {
          setData(dados?.collection?.items || [])
        })
        .catch(err => {
          console.error(err)
          setError(err.message)
        })
        .finally(() => setLoading(false))
    }, 500) // debounce

    return () => clearTimeout(delay)
  }, [busca])

  return (
    <div>
    <div className="container">

      <p>
        Aqui temos um vasto acervo de imagens da NASA. Busque por qualquer termo e clique para exibir a descrição completa
      </p>

      <h1>Busca NASA 🌐 </h1>
      <br />

      <div className="busca-box">
        <input
          type="text"
          value={busca}
          onChange={(e) => setBusca(e.target.value)}
          placeholder="Buscar imagens..."
        />
      </div>

      {loading && <p>Carregando...</p>}
      {error && <p>Erro: {error}</p>}

      <div className="galeria">
        {data.map((item, index) => (
          <div
            key={index}
            className="card"
            onClick={() => setSelecionado(item)}
          >
            {item.links && (
              <img src={item.links[0].href} alt="NASA" />
            )}
            <p>{item.data[0].title}</p>
          </div>
        ))}
      </div>

      {/* MODAL */}
      {selecionado && (
        <div className="modal" onClick={() => setSelecionado(null)}>
          <div
            className="modal-content"
            onClick={(e) => e.stopPropagation()}
          >
            {selecionado.links && (
              <img
                src={selecionado.links[0].href}
                alt="NASA"
              />
            )}

            <h2>{selecionado.data[0].title}</h2>

            <p>
              {selecionado.data[0].description ||
                "Sem descrição disponível"}
            </p>

            <button onClick={() => setSelecionado(null)}>
              Fechar
            </button>
          </div>
        </div>
      )}

    </div>
      <footer className='footer'>
      <p>
        Lucas Freitas • Análise e Desenvolvimento de Sistemas • UniSALESIANO • 2026
      </p>
      </footer>

    </div>
    
  )
}

export default Busca