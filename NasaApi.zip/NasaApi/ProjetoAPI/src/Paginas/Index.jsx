import { Link } from 'react-router-dom'
import './Index.css'

function Index() {
  return (
    <div>

      <div className="ind-container">

        <p>
          Sua janela para o universo. Utilize nossa integração com a API da NASA para navegar por conteúdos exclusivos e visualizar as fronteiras do espaço profundo em alta definição.
          Você pode navegar tanto pelos botões ou pela barra de navegação.
        </p>

        <p>
          O APOD (Astronomy Picture of the Day) apresenta diariamente uma imagem ou vídeo do espaço com explicação científica.
        </p>

        <Link to="/apod">
          <button className='botao'>
            🚀 EXPLORAR APOD
          </button>
        </Link>

        <p>
          O NeoWs fornece informações sobre asteroides próximos da Terra.
        </p>

        <Link to="/neows">
          <button className='botao'>
            🎯 EXPLORAR NEOWS
          </button>
        </Link>

        <p>
          A NASA Image and Video Library API permite acessar um grande acervo de imagens e vídeos espaciais.
        </p>

        <Link to="/busca">
          <button className='botao'>
            📁 EXPLORAR BIBLIOTECA
          </button>
        </Link>

      </div>

      <footer className='footer'>
        <p>
          Lucas Freitas • Análise e Desenvolvimento de Sistemas • UniSALESIANO • 2026
        </p>
      </footer>

    </div>
  )
}

export default Index