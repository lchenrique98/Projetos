import { useEffect, useState } from 'react'
import './Apod.css'

function Apod() {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    const loadData = async () => {
      setLoading(true)
      setError(null)

      try {
        const url =
          'https://api.nasa.gov/planetary/apod?api_key=2VBtklURLmmxVps31oi3x34Jszv2azUaWUQsA168'

        const res = await fetch(url)

        if (!res.ok) {
          throw new Error(`Erro HTTP: ${res.status}`)
        }

        const dadosApi = await res.json()

        if (!dadosApi.url) {
          throw new Error("Resposta inválida da API")
        }

        setData(dadosApi)

      } catch (err) {
        setError(err.message)
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [])

  if (loading) {
    return <h1 style={{ textAlign: 'center' }}>Explorando o universo 🛰️</h1>
  }

  if (error) {
    return (
      <div className="container">
        <p>Erro ao carregar dados 😕</p>
        <p>{error}</p>
      </div>
    )
  }

  return (
    <div>

      <div className='apod-container'>

        <h1 className='titulo'>SPACE TODAY</h1>

        <div className='diario-container'>
          <h5>Imagem atualizada diariamente</h5>
        </div>

        {data && (
          <div className="apod-hero">

            {/* IMAGEM */}
            <div className="apod-img">
              {data.media_type === 'image' ? (
                <img src={data.url} alt={data.title} />
              ) : (
                <iframe
                  src={data.url}
                  title="video"
                  allowFullScreen
                />
              )}
            </div>

            {/* TEXTO */}
            <div className="apod-info">
              <h2>{data.title}</h2>

              <p className="descricao">
                {data.explanation}
              </p>

              <p className="credito">
                Créditos: NASA / APOD
              </p>

            </div>

          </div>
        )}

      </div>

      <footer className='footer'>
        <p>
          Lucas Freitas • Análise e Desenvolvimento de Sistemas • UniSALESIANO • 2026
        </p>
      </footer>

    </div>
  )
}

export default Apod