import { useEffect, useState } from 'react'
import './NeoWs.css'

function NeoWs() {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [dataBusca, setDataBusca] = useState('2026-04-19')

  useEffect(() => {
    const loadData = () => {
      setLoading(true)

      fetch(`https://api.nasa.gov/neo/rest/v1/feed?start_date=${dataBusca}&end_date=${dataBusca}&api_key=2VBtklURLmmxVps31oi3x34Jszv2azUaWUQsA168`)
        .then(response => {
          if (!response.ok) throw new Error('Erro na API')
          return response.json()
        })
        .then(dadosApi => {
          setData(dadosApi)
          setLoading(false)
        })
        .catch(error => {
          console.error('Erro:', error)
          setLoading(false)
        })
    }

    loadData()
  }, [dataBusca])

  if (loading) {
    return <h1>Carregando asteroides ☄️</h1>
  }

  return (
    <div>
       
      <div className='neo-container'>
        <div className="conteudo">
          <h1 className='neo-titulo'>Asteroides próximos</h1>

          <p>Selecione uma data para visualizar os asteroides:</p>
          <small>A NASA não disponibilizou imagens desses corpos celestes.</small>

          <br />
          
          <input
            type="date"
            value={dataBusca}
            onChange={(e) => setDataBusca(e.target.value)}
          />

          <br /><br />

          {/* caso de erro de busca */}
          {data && Object.values(data?.near_earth_objects || {}).flat().length === 0 && (
            <p>Nenhum asteroide encontrado nessa data.</p>
          )}

          {/* lista */}
          {data && (
            <div className='astro-container'>
              {Object.values(data?.near_earth_objects || {})
                .flat()
                .map((asteroide) => (
                  <div key={asteroide.id} className='astro'>
                    <h2>{asteroide.name}</h2>

                    <p>
                      Tamanho máx:{" "}
                      {asteroide.estimated_diameter.meters.estimated_diameter_max.toFixed(0)} m
                    </p>

                    <p>
                      Velocidade:{" "}
                      {parseInt(
                        asteroide.close_approach_data[0].relative_velocity.kilometers_per_hour
                      )} km/h
                    </p>

                    <p>
                      Distância:{" "}
                      {parseInt(
                        asteroide.close_approach_data[0].miss_distance.kilometers
                      )} km
                    </p>

                    <p>
                      Perigoso:{" "}
                      {asteroide.is_potentially_hazardous_asteroid
                        ? "Sim ⚠️"
                        : "Não"}
                    </p>
                  </div>
                ))}
            </div>
          )}
        </div>
      </div>

        <footer className='footer'>
       <p>
        Lucas Freitas • Análise e Desenvolvimento de Sistemas • UniSALESIANO • 2026
       </p>
       </footer>
      </div>
  )
}

export default NeoWs