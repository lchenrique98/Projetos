import { Link } from 'react-router-dom'
import './Nav.css'

function Nav() {
  return (
<div className="nav">
  <div className="logo">E.xplore</div>

  <a href="/">INÍCIO</a>
  <a href="/apod">APOD</a>
  <a href="/neows">NEOWS</a>
  <a href="/busca">BUSCA</a>
</div>
  )
}

export default Nav