-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 02/06/2026 às 22:30
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `unisale`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `reclamacoes`
--

CREATE TABLE `reclamacoes` (
  `id` int(11) NOT NULL,
  `email_usuario` varchar(255) NOT NULL,
  `mensagem` text NOT NULL,
  `data_reclamacao` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `reclamacoes`
--

INSERT INTO `reclamacoes` (`id`, `email_usuario`, `mensagem`, `data_reclamacao`) VALUES
(1, 'lc.henrique08@gmail.com', '2323', '2026-05-31 22:46:47'),
(2, 'lc.henrique08@gmail.com', '23334', '2026-05-31 22:50:29');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `nome` varchar(40) DEFAULT NULL,
  `email` varchar(32) DEFAULT NULL,
  `senha` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`nome`, `email`, `senha`) VALUES
('Maria da Silva', 'maria@usuarios.com.br', 'c4ca4238a0b923820dcc509a6f75849b'),
('Andreia da Silva', 'andreia@usuarios.com.br', 'c4ca4238a0b923820dcc509a6f75849b'),
('Carlos da Silva', 'carlos@usuarios.com.br', 'c4ca4238a0b923820dcc509a6f75849b'),
('Caio da Silva', 'caio@usuarios.com.br', 'c4ca4238a0b923820dcc509a6f75849b'),
('Moura da Silva', 'moura@usuarios.com.br', 'c4ca4238a0b923820dcc509a6f75849b'),
('Oswaldo da Silva', 'oswaldo@usuarios.com.br', 'c4ca4238a0b923820dcc509a6f75849b'),
('Regina da Silva', 'regina@usuarios.com.br', 'c4ca4238a0b923820dcc509a6f75849b'),
('Jose da Silva', 'JosepCadura@gamil.com', 'c4ca4238a0b923820dcc509a6f75849b'),
('lolo', 'lolo@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b'),
('luana colto', 'luana@98gmail.com', '827ccb0eea8a706c4c34a16891f84e7b'),
('jose silva', 'jose@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b'),
('Lucas', 'lc.henrique08@gmail.com', '8dad0308d48afe1b28e3ff173407b6e3');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `reclamacoes`
--
ALTER TABLE `reclamacoes`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD KEY `endemail` (`email`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `reclamacoes`
--
ALTER TABLE `reclamacoes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
