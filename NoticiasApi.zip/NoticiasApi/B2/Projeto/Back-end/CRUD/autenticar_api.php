<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit;
}

require_once 'classes/Db.class.php';

$email = isset($_POST['email']) ? trim($_POST['email']) : '';
$senhaDigitada = isset($_POST['senha']) ? trim($_POST['senha']) : '';

if (empty($email) || empty($senhaDigitada)) {

    echo json_encode([
        "sucesso" => false,
        "mensagem" => "Por favor, preencha email e senha."
    ]);

    exit;
}

$senhaMd5 = md5($senhaDigitada);

try {

    $db = new Db();
    $db->conectar();
    $db->setTabela("usuarios");

    $where = "email = '$email' AND senha = '$senhaMd5'";

    $resultado = $db->consultar("*", $where);

    if (is_array($resultado) && count($resultado) > 0) {

        echo json_encode([
            "sucesso" => true,
            "mensagem" => "Bem-vindo!",
            "usuario" => $resultado[0]
        ]);

    } else {

        echo json_encode([
            "sucesso" => false,
            "mensagem" => "Email ou senha incorretos."
        ]);
    }

} catch (Exception $e) {

    echo json_encode([
        "sucesso" => false,
        "mensagem" => "Erro: " . $e->getMessage()
    ]);
}  