<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Content-Type: application/json");

require_once 'classes/Db.class.php';

$nome  = $_POST['nome'] ?? '';
$email = $_POST['email'] ?? '';
$senha = isset($_POST['senha']) ? md5($_POST['senha']) : '';

if (empty($nome) || empty($email) || empty($senha)) {
    echo json_encode(["sucesso" => false, "mensagem" => "Preencha todos os campos!"]);
    exit;
}

try {
    $db = new Db();
    $db->conectar();
    $db->setTabela("usuarios");

    $dados = [
        "nome"  => $nome,
        "email" => $email,
        "senha" => $senha
    ];

    if ($db->gravar($dados)) {
        echo json_encode(["sucesso" => true, "mensagem" => "Usuário cadastrado com sucesso!"]);
    } else {
        echo json_encode(["sucesso" => false, "mensagem" => "Erro ao gravar no banco."]);
    }
} catch (Exception $e) {
    echo json_encode(["sucesso" => false, "mensagem" => "Erro: " . $e->getMessage()]);
}