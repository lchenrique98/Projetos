<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    exit(0);
}

include("conexao.php");

$email = $_POST["email_usuario"] ?? "";
$mensagem = $_POST["mensagem"] ?? "";

if(empty($email) || empty($mensagem)){
    
    echo json_encode([
        "sucesso" => false,
        "mensagem" => "Dados inválidos"
    ]);

    exit;
}

$sql = "
INSERT INTO reclamacoes
(email_usuario, mensagem)
VALUES (?, ?)
";

$stmt = $conn->prepare($sql);

$stmt->bind_param(
    "ss",
    $email,
    $mensagem
);

$stmt->execute();

echo json_encode([
    "sucesso" => true
]);