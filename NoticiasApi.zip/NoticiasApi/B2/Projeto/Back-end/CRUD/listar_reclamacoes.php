<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

include("conexao.php");

$email = $_POST["email_usuario"] ?? "";

$sql = "
SELECT *
FROM reclamacoes
WHERE email_usuario = ?
ORDER BY data_reclamacao DESC
";

$stmt = $conn->prepare($sql);

$stmt->bind_param(
    "s",
    $email
);

$stmt->execute();

$resultado = $stmt->get_result();

$dados = [];

while($linha = $resultado->fetch_assoc()){
    $dados[] = $linha;
}

echo json_encode($dados);