<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Content-Type: application/json");


error_reporting(0); 
ini_set('display_errors', 0);

try {
    require_once 'classes/Db.class.php'; 
    require_once 'classes/Usuario.php';


    $cpf     = $_POST['cpf'] ?? '';
    $nome    = $_POST['nome'] ?? '';
    $celular = $_POST['celular'] ?? '';
    $email   = $_POST['email'] ?? '';
    $login   = $_POST['login'] ?? '';
    $senha   = isset($_POST['senha']) ? md5($_POST['senha']) : '';

    if (empty($login) || empty($senha)) {
        throw new Exception("Campos obrigatórios vazios.");
    }

    $db = new Db();
    $db->conectar();
    $db->setTabela("usuarios");

    $usuario = new Usuario($cpf, $nome, $celular, $email, $login, $senha);
    
    
    $sucesso = $usuario->gravar($db);

    echo json_encode([
        "sucesso" => (bool)$sucesso,
        "mensagem" => $sucesso ? "Cadastrado com sucesso!" : "Erro ao salvar no banco de dados."
    ]);

} catch (Exception $e) {
    echo json_encode([
        "sucesso" => false,
        "mensagem" => "Erro no servidor: " . $e->getMessage()
    ]);
}
exit;