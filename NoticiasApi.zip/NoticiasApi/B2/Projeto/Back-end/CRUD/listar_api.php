<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
require_once 'classes/Db.php';
require_once 'classes/Usuario.php';

$db = new Db();
$db->conectar();
$db->setTabela("usuarios");

$usuarios = $db->consultar();

echo json_encode($usuarios);
exit;