<?php
class Usuario {
    private $cpf;
    private $nome;
    private $celular;
    private $email;
    private $login;
    private $senha;

    function __construct($cpf, $nome, $celular, $email, $login, $senha){
        $this->cpf     = $cpf;
        $this->nome    = $nome;
        $this->celular = $celular;
        $this->email   = $email;
        $this->login   = $login;
        $this->senha   = $senha;
    }  

    public function gravar($banco) {
        $dados = [
            "cpf"     => $this->cpf,
            "nome"    => $this->nome,
            "celular" => $this->celular,
            "email"   => $this->email,
            "login"   => $this->login,
            "senha"   => $this->senha
        ];
       
        return $banco->gravar($dados); 
    }
}
?>