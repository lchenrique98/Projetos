<?php
class Db {
    private $host;
    private $porta;
    private $usudb;
    private $nomedb;
    private $senhadb;
    private $conexao;
    private $tabela;

    function __construct($host="127.0.0.1", $porta="3306", $usudb="root", $nomedb="unisale", $senhadb=""){
        $this->host = $host;
        $this->porta = $porta;
        $this->nomedb = $nomedb;
        $this->usudb = $usudb;
        $this->senhadb = $senhadb;
    }

      public function conectar(){
      $dados = "mysql:host=" . $this->host . ";port=" . $this->porta . ";dbname=" . $this->nomedb;
     try {
        $this->conexao = new PDO($dados, $this->usudb, $this->senhadb);
        $this->conexao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
       } catch(PDOException $e) {
        // Em vez de só guardar no log, vamos interromper com o erro real
        header('Content-Type: application/json');
        die(json_encode(["sucesso" => false, "mensagem" => "Erro de conexão: " . $e->getMessage()]));
      }
}

    public function setTabela($tabela = null){
        $this->tabela = $tabela;
    }

    public function executaSQL($query){
        $query = trim($query);
        $tipo = strtoupper(explode(' ', $query)[0]); // Pega a primeira palavra (SELECT, INSERT...)

        try {
            $stmt = $this->conexao->prepare($query);
            $executou = $stmt->execute();

            // Se for SELECT, retorna o array de dados
            if ($tipo === 'SELECT') {
                return $stmt->fetchAll(PDO::FETCH_ASSOC);
            }

            // Se for INSERT, UPDATE ou DELETE, retorna sucesso (true/false)
            return $executou;
        } catch (PDOException $e) {
            file_put_contents("erro.log", $e->getMessage(), FILE_APPEND);
            return false;
        }
    }

    public function gravar($dados = null){
        $campos = implode(",", array_keys($dados));
        $valores = implode("','", array_values($dados));
        $query = "INSERT INTO ".$this->tabela." (".$campos.") VALUES ('".$valores."')";
        return $this->executaSQL($query);
    }


    // Cole este bloco antes do último } da sua classe Db
    public function consultar($campos = '*', $where = null, $order = null, $limit = null) {
        $campos = is_null($campos) ? '*' : $campos;
        $where  = is_null($where)  ? ''  : 'WHERE ' . $where;
        $order  = is_null($order)  ? ''  : 'ORDER BY ' . $order;
        $limit  = is_null($limit)  ? ''  : 'LIMIT ' . $limit;

        $query = "SELECT " . $campos . " FROM " . $this->tabela . " " . $where . " " . $order . " " . $limit;
        
        // O executaSQL que você já tem vai rodar essa query e retornar o array
        return $this->executaSQL($query);
    }
  
    
}
?>