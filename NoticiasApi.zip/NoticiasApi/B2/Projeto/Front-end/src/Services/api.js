import axios from "axios";

const api = axios.create({
    baseURL:
    "http://localhost/B2/Projeto/Back-end/CRUD/"
});

export default api;