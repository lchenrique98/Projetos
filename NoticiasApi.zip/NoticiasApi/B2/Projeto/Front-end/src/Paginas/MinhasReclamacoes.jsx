import { useEffect, useState } from "react";
import api from "../services/api";
import "./MinhasReclamacoes.css";
import { Link } from "react-router-dom";

function MinhasReclamacoes() {

    const [lista, setLista] = useState([]);

    useEffect(() => {

        const usuario = JSON.parse(
            localStorage.getItem("usuario")
        );

        if (!usuario) {
            return;
        }

        const formData = new FormData();

        formData.append(
            "email_usuario",
            usuario.email
        );

        api.post(
            "listar_reclamacoes.php",
            formData
        )
        .then((response) => {

            setLista(response.data);

        })
        .catch((error) => {

            console.log(error);

        });

    }, []);

    return (

        <div className="historico-container">

            <h1>
                📋 Minhas Mensagens
            </h1>

            {lista.length === 0 ? (

                <div className="sem-reclamacoes">

                    <h2>
                        Nenhuma reclamação encontrada
                    </h2>

                    <p>
                        Você ainda não enviou nenhuma reclamação. Faça login e/ou envie a sua sujestão, queremos saber o que você acha. 
                    </p>

                </div>

            ) : (

                lista.map((item) => (

                    <div
                        key={item.id}
                        className="reclamacao-card"
                    >

                        <h3>
                            📋 Reclamação #{item.id}
                        </h3>

                        <p className="data-reclamacao">
                            📅 {item.data_reclamacao}
                        </p>

                        <div className="mensagem-reclamacao">
                            {item.mensagem}
                        </div>

                    </div>

                ))

            )}
                <br />
                            <Link
                    to="/contato"
                    className="btn-voltar"
                >
                    ← Voltar para Contato
                </Link>

        </div>

    );

}

export default MinhasReclamacoes;