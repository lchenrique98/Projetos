import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Favoritos.css";

function Favoritos(){

    const navigate = useNavigate();

    const [favoritos, setFavoritos] = useState([]);

    useEffect(() => {

        const usuario = localStorage.getItem("usuario");

        if(!usuario){

            navigate("/login");
            return;
        }

        const favoritosSalvos =
            JSON.parse(localStorage.getItem("favoritos")) || [];

        setFavoritos(favoritosSalvos);

    }, []);

    function sair(){

        localStorage.removeItem("usuario");
        localStorage.removeItem("favoritos");

        navigate("/login");
    }

    function removerFavorito(url){

        const novosFavoritos = favoritos.filter(
            item => item.url !== url
        );

        setFavoritos(novosFavoritos);

        localStorage.setItem(
            "favoritos",
            JSON.stringify(novosFavoritos)
        );
    }

    return(

        <div className="favoritos-container">

            <div className="favoritos-header">

                <h1>
                    Favoritos
                </h1>

                <button
                    onClick={sair}
                    className="btn-sair"
                >
                    Sair
                </button>

                <p>
                    Suas notícias salvas aparecerão aqui.
                </p>

            </div>

            <div className="grid-favoritos">

                {favoritos.length === 0 ? (

                    <p className="sem-favoritos">
                        Nenhuma notícia favoritada.
                    </p>

                ) : (

                    favoritos.map((noticia, index) => (

                        <div
                            key={index}
                            className="card-favorito"
                        >

                            <img
                                src={noticia.multimedia?.[0]?.url}
                                alt={noticia.title}
                                className="imagem-favorito"
                            />

                            <div className="conteudo-favorito">

                                <span className="tag-favorito">
                                    {noticia.section}
                                </span>

                                <h2>
                                    {noticia.title}
                                </h2>

                                <p>
                                    {noticia.abstract}
                                </p>

                                <div className="card-botoes">

                                        <a
                                            href={noticia.url}
                                            target="_blank"
                                            rel="noreferrer"
                                            className="btn-link"
                                        >
                                            Ler Mais
                                        </a>

                                        <button
                                            onClick={() => removerFavorito(noticia.url)}
                                            className="btn-remover"
                                        >
                                            Remover
                                        </button>

                                    </div>

                            </div>

                        </div>

                    ))

                )}

            </div>

        </div>
    );
}

export default Favoritos;