import { useState } from "react";
import api from "../services/api";
import {useNavigate, Link, useLocation} from "react-router-dom";
import "./Login.css";

function Login(){

    const [email, setEmail] = useState("");
    const [senha, setSenha] = useState("");
    const location = useLocation();

    const navigate = useNavigate();

    async function entrar(e){

        e.preventDefault();

        const formData = new FormData();

        formData.append("email", email);
        formData.append("senha", senha);

        try{

            const response = await api.post(
                "autenticar_api.php",
                formData
            );

            if(response.data.sucesso){

                localStorage.setItem(
                    "usuario",
                    JSON.stringify(response.data.usuario)
                );

                const destino =
                location.state?.voltarPara ||
                "/favoritos";

                navigate(destino);

            }else{

                alert(response.data.mensagem);

            }

        }catch(error){

            console.log(error);

            alert("Erro servidor");

        }

    
    }

    return(

        <div className="login-container">

            <div className="login-box">

                <h1>
                    Login
                </h1>

                <h5>
                    Para favoritar suas notícias, é necessário logar ou criar uma conta.
                </h5>

                <form onSubmit={entrar}>

                    <input
                        type="email"
                        placeholder="Email"
                        value={email}
                        onChange={(e)=>setEmail(e.target.value)}
                    />

                    <input
                        type="password"
                        placeholder="Senha"
                        value={senha}
                        onChange={(e)=>setSenha(e.target.value)}
                    />

                    <button type="submit">
                        Entrar
                    </button>

                </form>

                <Link
                    to="/cadastro"
                    className="link-cadastro"
                >
                    Criar Conta
                </Link>

            </div>

        </div>

    );
}

export default Login;