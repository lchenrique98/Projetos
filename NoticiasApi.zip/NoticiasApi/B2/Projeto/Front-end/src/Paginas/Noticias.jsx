import { useEffect, useState } from "react";
import axios from "axios";
import "./Noticias.css";
import { useNavigate } from "react-router-dom";

function Noticias() {

  const [noticias, setNoticias] = useState([]);
  const [loading, setLoading] = useState(true);
  const [categoria, setCategoria] = useState("home");
  const [busca, setBusca] = useState("");
  const [favoritos, setFavoritos] = useState([]);

  const navigate = useNavigate();

  const API_KEY = "6HzzG38ds2Ilx7GsWaD9JG4P75dh6s7tgRQHAweGIP6XTffw";
  useEffect(() => {

    buscarNoticias();

    const favoritosSalvos =
      JSON.parse(localStorage.getItem("favoritos")) || [];

    setFavoritos(favoritosSalvos);

  }, [categoria]);


  async function buscarNoticias() {

    setLoading(true);

    try {

      const resposta = await axios.get(
        `https://api.nytimes.com/svc/topstories/v2/${categoria}.json`,
        {
          params: {
            "api-key": API_KEY
          }
        }
      );

      setNoticias(resposta.data.results);

    } catch (erro) {

      console.log("Erro ao buscar notícias", erro);

    } finally {

      setLoading(false);

    }

  }


  function adicionarFavorito(noticia) {

    // confere o login
    const usuario = JSON.parse(
      localStorage.getItem("usuario")
    );

    if (!usuario) {

      navigate("/login");

      return;
    }

    // verifica a favoritação e remove
    const existe = favoritos.find(
      item => item.url === noticia.url
    );


    if (existe) {

      const novosFavoritos = favoritos.filter(
        item => item.url !== noticia.url
      );

      setFavoritos(novosFavoritos);

      localStorage.setItem(
        "favoritos",
        JSON.stringify(novosFavoritos)
      );

      return;

    }

    //  adiciona o fav
    const novosFavoritos = [...favoritos, noticia];

    setFavoritos(novosFavoritos);

    localStorage.setItem(
      "favoritos",
      JSON.stringify(novosFavoritos)
    );

  }


  const noticiasFiltradas = noticias.filter((noticia) =>
    noticia.title
      .toLowerCase()
      .includes(busca.toLowerCase())
  );


  return (

    <div className="noticias-container">


      <div className="noticias-header">

        <div>

          <h1 className="h1">Últimas Notícias</h1>

          <p>
            Notícias em tempo real usando a API do New York Times.
          </p>

        </div>

        <input
          type="text"
          placeholder="Buscar notícias..."
          value={busca}
          onChange={(e) => setBusca(e.target.value)}
          className="input-busca"
        />

      </div>


      <div className="categorias">

        {[
          "home",
          "world",
          "technology",
          "science",
          "sports",
          "business",
          "movies"
        ].map((item) => (

          <button
            key={item}
            onClick={() => setCategoria(item)}
            className={
              categoria === item
                ? "btn-categoria btn-ativo"
                : "btn-categoria"
            }
          >
            {item}
          </button>

        ))}

      </div>


      {loading && (

        <div className="loading">
          Carregando notícias...
        </div>

      )}


      <div className="grid-noticias">

        {!loading && noticiasFiltradas.map((noticia, index) => {

          const imagem = noticia.multimedia?.[0]?.url;

          const favoritado = favoritos.find(
            item => item.url === noticia.url
          );

          return (

            <div
              key={index}
              className="card-noticia"
            >

              {/* IMAGEM */}
              <div className="card-imagem">

                <img
                  src={imagem}
                  alt={noticia.title}
                />

              </div>


       
              <div className="card-conteudo">

                <span className="tag">
                  {noticia.section}
                </span>


                <h2>
                  {noticia.title}
                </h2>


                <p>
                  {noticia.abstract}
                </p>


                <div className="card-footer">

                  <button
                    onClick={() => adicionarFavorito(noticia)}
                    className={
                      favoritado
                        ? "btn-favorito btn-favoritado"
                        : "btn-favorito"
                    }
                  >
                    {favoritado
                      ? "❤️ Favoritado"
                      : "🤍 Favoritar"}
                  </button>


                  <a
                    href={noticia.url}
                    target="_blank"
                    rel="noreferrer"
                    className="btn-link"
                  >
                    Ler Mais
                  </a>

                </div>

              </div>

            </div>

          );

        })}

      </div>

    </div>

  );

}

export default Noticias;