import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import "./Home.css";


function Home() {

  const [noticias, setNoticias] = useState([]);
  const [carregando, setCarregando] = useState(true);

  const API_KEY = "6HzzG38ds2Ilx7GsWaD9JG4P75dh6s7tgRQHAweGIP6XTffw";

  useEffect(() => {

    axios.get(
      `https://api.nytimes.com/svc/topstories/v2/home.json?api-key=${API_KEY}`
    )
    .then((response) => {

      console.log(response.data);

      setNoticias(response.data.results || []);

      setCarregando(false);

    })
    .catch((error) => {

      console.log(error);

      setCarregando(false);

    });

  }, []);

  if (carregando) {
    return <h1 className="aviso">Carregando...</h1>;
  }

  if (!noticias.length) {
    return <h1 className="aviso">Nenhuma notícia encontrada</h1>;
  }

  /* Banner */
  const banner =
    noticias.find(
      (item) =>
        item.multimedia &&
        item.multimedia.length > 0
    );

  if (!banner) {
    return <h1>Nenhum banner disponível</h1>;
  }

  return (
   
    <div className="home">

      
      <section
        className="hero"
        style={{
          backgroundImage: `
            linear-gradient(
              rgba(0,0,0,0.7),
              rgba(0,0,0,0.7)
            ),
            url(${banner.multimedia[0].url})
          `
        }}
      >

        <div className="hero-content">

          <span className="hero-section">
            {banner.section}
          </span>

          <h1>
            {banner.title}
          </h1>

          <p>
            {banner.abstract}
          </p>

          <a
            href={banner.url}
            target="_blank"
            rel="noreferrer"
            className="hero-button"
          >
            Ler notícia
          </a>

        </div>

      </section>

      
      <section className="destaques">

        <h2>
          Destaques
        </h2>

        <div className="destaques-grid">

          {noticias
            .filter(
              (item) =>
                item.multimedia &&
                item.multimedia.length > 0
            )
            .slice(1, 4)
            .map((artigo) => (

              <article
                key={artigo.url}
                className="destaque-card"
              >

                <img
                  src={artigo.multimedia[0].url}
                  alt={artigo.title}
                />

                <div className="destaque-content">

                  <span>
                    {artigo.section}
                  </span>

                  <h3>
                    {artigo.title}
                  </h3>

                  <p>
                    {artigo.abstract}
                  </p>

                </div>

              </article>

          ))}

        </div>

      </section>
   

    </div>
    
  );
}

export default Home;