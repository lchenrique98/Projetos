import "./Contato.css";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";
import api from "../services/api";


function Contato(){
    const [mensagem, setMensagem] = useState("");
    const navigate = useNavigate();

    async function enviarMensagem(e){

    e.preventDefault();

    const usuario = JSON.parse(
        localStorage.getItem("usuario")
    );

   if(!usuario){

    const confirmar = window.confirm(
        "Você precisa estar logado para enviar uma reclamação.\n\nDeseja ir para a página de login?"
    );

    if(confirmar){
        navigate("/login", {
            state: { 
                voltarPara: "/contato"
            }
        });
    }

    return;
}
        if(!mensagem.trim()){

    alert(
        "Digite uma reclamação."
    );

    return;
}

const formData = new FormData();

formData.append(
    "email_usuario",
    usuario.email
);

formData.append(
    "mensagem",
    mensagem
);

        try{

            await api.post(
                "salvar_reclamacao.php",
                formData
            );

            alert(
                "Reclamação enviada com sucesso!"
            );

            setMensagem("");

        }catch(error){

            console.log(error);

            alert(
                "Erro ao enviar reclamação."
            );

        }

        }



     return(

        <div className="contato-container">

            <div className="contato-card">

                <h1>
                    Contato
                </h1>

                <p className="descricao">

                    Entre em contato para dúvidas, sugestões
                    ou informações sobre o projeto.

                </p>

                <div className="info-contato">

                    <div className="item-contato">
                        <span>👨‍💻</span>
                        <p>Lucas Freitas</p>
                    </div>

                    <div className="item-contato">
                        <span>🆔</span>
                        <p>RA: 221004</p>
                    </div>

                    <div className="item-contato">
                        <span>🏫</span>
                        <p>UniSalesiano-Araçatuba SP</p>
                    </div>

                    <div className="item-contato">
                        <span>💻</span>
                        <p>Analíse e Desenvolvimento de Sistemas </p>
                    </div>

                    <div className="item-contato">
                        <span>📧</span>
                        <p>lucas@email.com</p>
                    </div>

                </div>

                <form className="form-contato" onSubmit={enviarMensagem}>

                    <input
                        type="text"
                        placeholder="Seu nome"
                    />

                    <input
                        type="email"
                        placeholder="Seu email"
                    />

                    <textarea
                        placeholder="Digite sua reclamação"
                        value={mensagem}
                        onChange={(e) => setMensagem(e.target.value)}
                    ></textarea>

                    <button type="submit">
                        Enviar Mensagem
                    </button>
                </form>

                             <Link
                        to="/minhas-reclamacoes"
                        className="btn-historico"
                    >
                        📋 Minhas  Mensagens
                    </Link>


            </div>

        </div>
    );
}

export default Contato;