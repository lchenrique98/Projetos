import { useState } from "react";
import axios from "axios";
import "./Login.css";
import { Link } from "react-router-dom";

function Cadastro() {

  const [nome, setNome] = useState("");
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [confirmarSenha, setConfirmarSenha] = useState("");

  async function cadastrar(e) {

    e.preventDefault();

    if (senha !== confirmarSenha) {

      alert("As senhas não coincidem!");
      return;

    }

    const formData = new FormData();

    formData.append("nome", nome);
    formData.append("email", email);
    formData.append("senha", senha);

    try {

      const resposta = await axios.post(
        "http://localhost/CRUD/cadastrar_api.php",
        formData
      );

      if (resposta.data.sucesso) {

        alert("Usuário cadastrado!");

        setNome("");
        setEmail("");
        setSenha("");
        setConfirmarSenha("");

      } else {

        alert(resposta.data.mensagem);

      }

    } catch (erro) {

      console.log(erro);
      alert("Erro ao cadastrar");

    }
  }

  return (

    <div className="login-container">

      <div className="login-box">

        <h1>Cadastro</h1>

        <form onSubmit={cadastrar}>

          <input
            type="text"
            placeholder="Nome"
            value={nome}
            onChange={(e) => setNome(e.target.value)}
          />

          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />

          <input
            type="password"
            placeholder="Senha"
            value={senha}
            onChange={(e) => setSenha(e.target.value)}
          />

          <input
            type="password"
            placeholder="Confirmar senha"
            value={confirmarSenha}
            onChange={(e) => setConfirmarSenha(e.target.value)}
          />

          <button type="submit">
            Cadastrar
          </button>
        </form>

              <Link
                    to="/login"
                    className="link-cadastro"
                >
                    Voltar ao login
                </Link>

      </div>

    </div>
  );
}

export default Cadastro;