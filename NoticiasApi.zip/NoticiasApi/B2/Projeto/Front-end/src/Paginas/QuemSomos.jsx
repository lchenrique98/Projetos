import "./QuemSomos.css";

function QuemSomos(){

    return(

        <div className="sobre-container">

            <div className="sobre-card">

                <img
                    src="src/Imagem/622f13ec-f461-4210-8cf1-3bf0c18b6c31.jpg"
                    alt="Lucas Freitas"
                    className="foto-perfil"
                />

                <h1>
                    Sobre Nós
                </h1>

                <p className="descricao">
                    
                    Este portal de notícias foi desenvolvido como projeto acadêmico com o objetivo de aplicar, na prática, os conhecimentos adquiridos durante o curso de desenvolvimento de sistemas. A plataforma permite que os usuários acompanhem notícias atualizadas de forma simples, rápida e organizada.

                    Para a construção do projeto, foi utilizado o React, responsável pela criação das telas e pela interação do usuário com o sistema. No desenvolvimento do servidor e das funcionalidades internas, foi utilizado o **PHP**, que faz a comunicação entre a aplicação e o banco de dados.

                    Os dados dos usuários e informações do sistema são armazenados em um banco de dados MySQL, garantindo organização e segurança das informações. Além disso, o portal utiliza a **API do New York Times**, que fornece notícias atualizadas automaticamente para serem exibidas na plataforma.

                    O projeto também foi desenvolvido com foco em uma navegação simples e responsiva, permitindo que o portal seja acessado tanto em computadores quanto em dispositivos móveis.

                    Dessa forma, este trabalho demonstra a integração entre diferentes tecnologias utilizadas no desenvolvimento web moderno, proporcionando uma experiência prática de aprendizado e a criação de uma aplicação funcional e útil para os usuários.


                </p>

                <div className="info">

                    <h2>
                        Lucas Freitas
                    </h2>

                    <p>
                        RA: 221004
                    </p>

                    <p>
                        Curso: Análise e Desenvolviemnto de Sistemas (ADS)
                    </p>

                    <p>
                        Instituição: UniSalesiano- Araçatuba SP
                    </p>

                </div>

               
            </div>

        </div>

    );
}

export default QuemSomos;