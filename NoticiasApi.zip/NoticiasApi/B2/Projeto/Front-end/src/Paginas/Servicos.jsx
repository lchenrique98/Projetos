import "./Servicos.css";
import { useState } from "react";

function Servicos(){

    const servicos = [

        {
            titulo:"Clima",
            emoji:"🌤️",
            descricao:"Veja previsão do tempo em tempo real.",
            link:"https://weather.com/"
        },

        {
            titulo:"Receitas",
            emoji:"👨🏽‍🍳",
            descricao:"Explore receitas e culinária.",
            link:"https://www.tudogostoso.com.br/"
        },

        {
            titulo:"Filmes",
            emoji:"🎬",
            descricao:"Confira trailers e lançamentos.",
            link:"https://www.themoviedb.org/"
        },

        {
            titulo:"Esportes",
            emoji:"⚽",
            descricao:"Notícias esportivas atualizadas.",
            link:"https://ge.globo.com/"
        },

        {
            titulo:"Cotação",
            emoji:"💱",
            descricao:"Dólar, euro e bitcoin em tempo real.",
            link:"https://www.google.com/finance/"
        },

        {
            titulo:"Games",
            emoji:"🎮",
            descricao:"Veja como esta o mundo GAMING hoje.",
            link:"https://www.adrenaline.com.br/"
        }

    ];

    return(

        <div className="servicos-container">

            <div className="servicos-header">

                <h1 className="h1">
                    +Serviços
                </h1>

                <p>
                    Explore outros serviços e plataformas digitais.
                </p>

            </div>

            <div className="grid-servicos">

                {servicos.map((item, index)=>(

                    <div
                        key={index}
                        className="card-servico"
                    >

                        <div className="emoji">
                            {item.emoji}
                        </div>

                        <h2>
                            {item.titulo}
                        </h2>

                        <p>
                            {item.descricao}
                        </p>

                        <a
                            href={item.link}
                            target="_blank"
                            rel="noreferrer"
                            className="btn-servico"
                        >
                            Acessar
                        </a>

                    </div>

                ))}

            </div>

        </div>
    );
}

export default Servicos;