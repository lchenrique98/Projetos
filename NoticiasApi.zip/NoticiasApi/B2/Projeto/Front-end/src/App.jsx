import {
  BrowserRouter,
  Routes,
  Route,
  Link
} from "react-router-dom";

import { useState } from "react";

import Home from "./paginas/Home";
import Noticias from "./paginas/Noticias";
import Servicos from "./paginas/Servicos";
import Favoritos from "./paginas/Favoritos";
import QuemSomos from "./paginas/QuemSomos";
import Login from "./paginas/Login";
import Cadastro from "./paginas/Cadastro";
import Contato from "./paginas/Contato";
import MinhasReclamacoes from "./paginas/MinhasReclamacoes";



import "./App.css";

function App() {
   const [menuAberto, setMenuAberto] = useState(false);

  return (

    <BrowserRouter>

      <div className="layout">

            <button
    className="menu-mobile"
    onClick={() => setMenuAberto(!menuAberto)}
  >
    ☰
  </button>

        {/* SIDEBAR */}
        <aside className={`sidebar ${menuAberto ? "ativo" : ""}`}>

          <h2 className="logo">
            LFNews
          </h2>

          <nav className="menu">

            <Link to="/">
              Home
            </Link>

            <Link to="/noticias">
              Notícias
            </Link>

            <Link to="/servicos">
              +Serviços
            </Link>

            <Link to="/favoritos">
              Favoritos
            </Link>

            <Link to="/quem-somos">
              Quem Somos
            </Link>

            <Link to= "/contato">
              Contato
            </Link>

          </nav>

        </aside>

        {/* CONTEÚDO */}
        <div className="content">

          {/* PÁGINAS */}
          <main className="page-content">

            <Routes>

              <Route
                path="/"
                element={<Home />}
              />

              <Route
                path="/noticias"
                element={<Noticias />}
              />

              <Route
                path="/servicos"
                element={<Servicos />}
              />

              <Route
                path="/favoritos"
                element={<Favoritos />}
              />

              <Route
                path="/quem-somos"
                element={<QuemSomos />}
              />

              <Route
                path="/login"
                element={<Login />}
              />

              <Route
                path="/cadastro"
                element={<Cadastro />}
              />

              <Route 
                path="/contato"
                element={<Contato />}
              />


                <Route
              path="/minhas-reclamacoes"
              element={<MinhasReclamacoes />}
            />
            
            </Routes>

          

          </main>

          {/* FOOTER */}
          <footer className="mt-10 bg-gradient-to-br from-black to-zinc-900 text-white mx-6 mb-6 rounded-[35px] overflow-hidden shadow-2xl border border-zinc-800">

            <div className="grid md:grid-cols-[1.2fr_1fr_1fr] gap-10 px-14 py-12">

              {/* LOGO */}
              <div>

                <h2 className="text-5xl font-extrabold text-orange-400 mb-5 tracking-tight">
                  LFNews
                </h2>

                <p className="text-gray-300 leading-7 text-base max-w-sm">
                  Portal de notícias moderno com
                  informações em tempo real usando
                  a API do New York Times.
                </p>

              </div>

              {/* NAVEGAÇÃO */}
              <div>

                <h3 className="text-3xl font-bold mb-6">
                  Navegação
                </h3>

                <ul className="space-y-4 text-base">

                  <li>
                    <Link
                      to="/"
                      className="text-gray-300 hover:text-orange-400 transition duration-300"
                    >
                      Home
                    </Link>
                  </li>

                  <li>
                    <Link
                      to="/noticias"
                      className="text-gray-300 hover:text-orange-400 transition duration-300"
                    >
                      Notícias
                    </Link>
                  </li>

                  <li>
                    <Link
                      to="/servicos"
                      className="text-gray-300 hover:text-orange-400 transition duration-300"
                    >
                     +Serviços
                    </Link>
                  </li>

                  <li>
                    <Link
                      to="/favoritos"
                      className="text-gray-300 hover:text-orange-400 transition duration-300"
                    >
                      Favoritos
                    </Link>
                  </li>

                     <li>
                    <Link
                      to="/quemSomos"
                      className="text-gray-300 hover:text-orange-400 transition duration-300"
                    >
                      Quem-Somos
                    </Link>
                  </li>

                     <li>
                    <Link
                      to="/contato"
                      className="text-gray-300 hover:text-orange-400 transition duration-300"
                    >
                      Contato
                    </Link>
                  </li>

                </ul>

              </div>

              {/* DEV */}
              <div>

                <h3 className="text-3xl font-bold mb-6">
                  Desenvolvedor
                </h3>

                <div className="space-y-3 text-base">

                  <p className="text-gray-300">
                    Lucas Freitas
                  </p>

                  <p className="text-gray-400">
                    RA: 221004
                  </p>

                  <p className="text-gray-400">
                    UniSalesiano
                  </p>

                </div>

              </div>

            </div>

            {/* COPYRIGHT */}
            <div className="border-t border-zinc-800 py-5 text-center text-gray-500 text-sm bg-black/40">

              © 2026 LFNews - Todos os direitos reservados.

            </div>

          </footer>

        </div>

      </div>

    </BrowserRouter>
  );
}

export default App;